document.querySelectorAll('button').forEach(btn => {
  btn.onclick = () => alert('Thank you for your interest! Coming soon...');
});